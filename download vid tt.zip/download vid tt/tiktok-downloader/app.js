const express = require("express");
const axios = require("axios");
const bodyParser = require("body-parser");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "public")));

app.post("/download", async (req, res) => {
  const { url } = req.body;

  if (!url) {
    return res.status(400).json({ error: "URL is required" });
  }

  const apiUrl = `https://api.tiklydown.eu.org/`;

  try {
    const response = await axios.get(apiUrl);
    const data = response.data;

    // Log the API response for debugging purposes
    console.log("API Response:", data);

    // Check if the response contains a download URL
    if (!data || !data.download_url) {
      return res
        .status(500)
        .json({ error: "Failed to retrieve the download link" });
    }

    // Send the download URL back to the client
    res.json({ download_url: data.download_url });
  } catch (error) {
    console.error("Error retrieving download link:", error.message);
    res.status(500).json({ error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
